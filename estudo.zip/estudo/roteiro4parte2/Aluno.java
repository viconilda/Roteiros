package roteiro4parte2;

public class Aluno {
    public int matricula;
    public String nome;
    public String curso;
    public int anoIngresso;

    
    public Aluno(int pMatricula, String pNome, String pCurso, int pAnoIngresso) {
        matricula = pMatricula;
        nome = pNome;
        curso = pCurso;
        anoIngresso = pAnoIngresso;
    }
}