package roteiro6parte2;

class Tempo {
    private int hora;
    private int minuto;
    private int segundo;

    
    public Tempo(int hora, int minuto, int segundo) {
        this.hora = hora;
        this.minuto = minuto;
        this.segundo = segundo;
    }

   
    public int getHora() {
        return hora;
    }

    public void setHora(int hora) {
        this.hora = hora;
    }

    public int getMinuto() {
        return minuto;
    }

    public void setMinuto(int minuto) {
        this.minuto = minuto;
    }

    public int getSegundo() {
        return segundo;
    }

    public void setSegundo(int segundo) {
        this.segundo = segundo;
    }
}


 class Ligacao {
    private String numOrigem;
    private String numDestino;
    private String localOrigem;
    private String localDestino;
    private Tempo horaInicio;
    private Tempo horaFim;

    
    public Ligacao(String numOrigem, String numDestino, String localOrigem, String localDestino, Tempo horaInicio) {
        this.numOrigem = numOrigem;
        this.numDestino = numDestino;
        this.localOrigem = localOrigem;
        this.localDestino = localDestino;
        this.horaInicio = horaInicio;
        this.horaFim = null;
    }

  
    public String getNumOrigem() {
        return numOrigem;
    }

    public void setNumOrigem(String numOrigem) {
        this.numOrigem = numOrigem;
    }

    public String getNumDestino() {
        return numDestino;
    }

    public void setNumDestino(String numDestino) {
        this.numDestino = numDestino;
    }

    public String getLocalOrigem() {
        return localOrigem;
    }

    public void setLocalOrigem(String localOrigem) {
        this.localOrigem = localOrigem;
    }

    public String getLocalDestino() {
        return localDestino;
    }

    public void setLocalDestino(String localDestino) {
        this.localDestino = localDestino;
    }

    public Tempo getHoraInicio() {
        return horaInicio;
    }

    public void setHoraInicio(Tempo horaInicio) {
        this.horaInicio = horaInicio;
    }

    public Tempo getHoraFim() {
        return horaFim;
    }

    public void setHoraFim(Tempo horaFim) {
        this.horaFim = horaFim;
    }

    
    public void encerrarLigacao(Tempo horaFim) {
        this.horaFim = horaFim;
    }

  
    public String calcularDuracao() {
        if (horaInicio == null || horaFim == null) {
            return "Não é possível calcular a duração. Horários de início ou término não estão preenchidos.";
        }

        return "Duração da ligação: Desconhecida";
    }
}


public class Principal {
    public static void main(String[] args) {
        
        Tempo horaInicio = new Tempo(10, 15, 2);

       
        Ligacao lig01 = new Ligacao("121212", "565656", "A", "B", horaInicio);

      
        System.out.println("Número de Origem: " + lig01.getNumOrigem());
        System.out.println("Número de Destino: " + lig01.getNumDestino());
        System.out.println("Local de Origem: " + lig01.getLocalOrigem());
        System.out.println("Local de Destino: " + lig01.getLocalDestino());
        System.out.println("Hora de Início: " + lig01.getHoraInicio().getHora() + ":" +
                lig01.getHoraInicio().getMinuto() + ":" +
                lig01.getHoraInicio().getSegundo());
        System.out.println("Hora de Término: " + (lig01.getHoraFim() != null ?
                lig01.getHoraFim().getHora() + ":" +
                lig01.getHoraFim().getMinuto() + ":" +
                lig01.getHoraFim().getSegundo() : "Não definido"));

        
        Tempo horaFim = new Tempo(10, 20, 35);
        lig01.encerrarLigacao(horaFim);

       
        System.out.println(lig01.calcularDuracao());
    }
}