package roteiros.roteiro9.parte1;

public interface FiguraGeometrica {
    public String getNomeFigura();
    public double getArea();
    public double getPerimetro();
}
