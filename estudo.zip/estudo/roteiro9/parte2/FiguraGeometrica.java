package roteiros.roteiro9.parte2;

public interface FiguraGeometrica {
    public String getNomeFigura();
    public double getArea();
    public double getPerimetro();
}
