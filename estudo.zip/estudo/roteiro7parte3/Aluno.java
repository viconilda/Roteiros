package roteiro7parte3;

import java.util.ArrayList;
import java.util.Scanner;

public class Aluno {
    private int matricula;
    private String nome;
    private String curso;
    private int anoIngresso;
    private ArrayList<String> listaDisciplinas;

    public Aluno(int matricula, String nome, String curso, int anoIngresso) {
        this.matricula = matricula;
        this.nome = nome;
        this.curso = curso;
        this.anoIngresso = anoIngresso;
        this.listaDisciplinas = new ArrayList<>();
    }

    public int getMatricula() {
        return matricula;
    }

    public void setMatricula(int matricula) {
        this.matricula = matricula;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCurso() {
        return curso;
    }

    public void setCurso(String curso) {
        this.curso = curso;
    }

    public int getAnoIngresso() {
        return anoIngresso;
    }

    public void setAnoIngresso(int anoIngresso) {
        this.anoIngresso = anoIngresso;
    }

    public ArrayList<String> getListaDisciplinas() {
        return listaDisciplinas;
    }

    public void adicionarDisciplina(String disciplina) {
        this.listaDisciplinas.add(disciplina);
    }

    public void listarDisciplinas() {
        System.out.println("Disciplinas do Aluno:");
        for (String disciplina : listaDisciplinas) {
            System.out.println("- " + disciplina);
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

   
        System.out.println("Informe os dados do aluno:");
        System.out.print("Matrícula: ");
        int matricula = scanner.nextInt();
        scanner.nextLine(); 
        System.out.print("Nome: ");
        String nome = scanner.nextLine();
        System.out.print("Curso: ");
        String curso = scanner.nextLine();
        System.out.print("Ano de Ingresso: ");
        int anoIngresso = scanner.nextInt();

        Aluno aluno = new Aluno(matricula, nome, curso, anoIngresso);

        System.out.println("Informe as disciplinas do aluno (digite 'fim' para encerrar):");
        while (true) {
            System.out.print("Disciplina: ");
            String disciplina = scanner.next();
            if (disciplina.equals("fim")) {
                break;
            }
            aluno.adicionarDisciplina(disciplina);
        }

        aluno.listarDisciplinas();

       
        System.out.println("Quantidade de disciplinas: " + aluno.getListaDisciplinas().size());

        scanner.close();
    }
}
