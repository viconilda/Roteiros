import java.util.Scanner;

public class Prova {
public static void main(String[] args) {
Scanner scanner = new Scanner(System.in);

System.out.println("Digite o valor de X:");
double x = scanner.nextDouble();

System.out.println("Digite o valor de Y:");
double y = scanner.nextDouble();

System.out.println("Digite o valor de Z:");
double z = scanner.nextDouble();

if (x < y + z && y < x + z && z < x + y && x > 0 && y > 0 && z > 0){
System.out.println("Forma um triângulo.");
} else {
System.out.println("Não forma um triângulo.");
}
}
}