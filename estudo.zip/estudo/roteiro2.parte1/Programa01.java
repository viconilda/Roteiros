
package roteiro2.parte1;

public class Programa01 {

    public static void main(String[] args) {
        int idade = 18;
        char letra = 'a';
        float numeroFloat = 3.14159f;
        double numeroDouble = 2.71828;
        String nome = "Issac Newton";
        
        System.out.println("Exibir : " + numeroFloat); //ou "exibir : " + nome//
    }
}
