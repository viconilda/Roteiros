import java.util.Scanner;

public class Prova2 {
public static void main(String[] args) {
Scanner scanner = new Scanner(System.in);

System.out.println("Digite número o 1:");
double numero1 = scanner.nextDouble();

System.out.println("Digite o número 2:");
double numero2 = scanner.nextDouble();

System.out.println("Digite o número 3:");
double numero3 = scanner.nextDouble();


System.out.println("Escolha uma ordem:");
System.out.println("1 - Ordem crescente");
System.out.println("2 - Ordem decrescente");
System.out.println("3 - Maior número entre os outros dois");

int opcao = scanner.nextInt();


if (opcao == 1) {
ordemCrescente(numero1, numero2, numero3);
} else if (opcao == 2) {
ordemDecrescente(numero1, numero2, numero3);
} else if (opcao == 3) {
maiorMeio(numero1, numero2, numero3);
} else {
System.out.println("Opção inválida.");
}
}

public static void ordemCrescente(double num1, double num2, double num3) {
double menor, meio, maior;
if (num1 <= num2 && num1 <= num3) {
menor = num1;
if (num2 <= num3) {
meio = num2;
maior = num3;
} else {
meio = num3;
maior = num2;
}
} else if (num2 <= num1 && num2 <= num3) {
menor = num2;
if (num1 <= num3) {
meio = num1;
maior = num3;
} else {
meio = num3;
maior = num1;
}
} else {
menor = num3;
if (num1 <= num2) {
meio = num1;
maior = num2;
} else {
meio = num2;
maior = num1;
}
}
System.out.println(menor + ", " + meio + ", " + maior);
}

public static void ordemDecrescente(double num1, double num2, double num3) {
double maior, meio, menor;
if (num1 >= num2 && num1 >= num3) {
maior = num1;
if (num2 >= num3) {
meio = num2;
menor = num3;
} else {
meio = num3;
menor = num2;
}
} else if (num2 >= num1 && num2 >= num3) {
maior = num2;
if (num1 >= num3) {
meio = num1;
menor = num3;
} else {
meio = num3;
menor = num1;
}
} else {
maior = num3;
if (num1 >= num2) {
meio = num1;
menor = num2;
} else {
meio = num2;
menor = num1;
}
}
System.out.println(maior + ", " + meio + ", " + menor);
}

public static void maiorMeio(double num1, double num2, double num3) {
double maior, meio, menor;
if (num1 >= num2 && num1 >= num3) {
maior = num1;
if (num2 >= num3) {
meio = num2;
menor = num3;
} else {
meio = num3;
menor = num2;
}
} else if (num2 >= num1 && num2 >= num3) {
maior = num2;
if (num1 >= num3) {
meio = num1;
menor = num3;
} else {
meio = num3;
menor = num1;
}
} else {
maior = num3;
if (num1 >= num2) {
meio = num1;
menor = num2;
} else {
meio = num2;
menor = num1;
}
}
System.out.println(menor + ", " + maior + ", " + meio);
}

}