package roteiro3;

import java.util.Scanner;

public class Programa12{

    public static void main(String[] args) {
        
        Scanner entrada = new Scanner (System.in);

        float sb, grat, sr;
        
        System.out.println("Informe o Salário Base :");
        sb = entrada.nextFloat();
        grat = calcGrat(sb);
        

        System.out.println("Salário a receber : " + grat);
    }
    
    public static float calcGrat(float sb)
    {
    return  sb + (sb * 5/100) - (sb * 7/100);
    }

}