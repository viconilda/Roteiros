package roteiro2;

import java.util.Random;
import java.util.Scanner;

public class SecNum {
    
public static void main(String[] args) {

Scanner entrada = new Scanner(System.in);    

Random random = new Random();

int numeroSecreto = random.nextInt(100) + 1;
//System.out.println("O numero sorteado é: " + numeroSecreto);//

int tentativa = 0;
        
        while (tentativa != numeroSecreto) {
            System.out.println("Tente adivinhar numero entre 1 e 100): ");
            tentativa = entrada.nextInt();
            
            if (tentativa < numeroSecreto) {
                System.out.println("Tente um numero maior");
            } else if (tentativa > numeroSecreto) {
                System.out.println("Tente um numero menor");
            } else {
                System.out.println("Correto: " + numeroSecreto);
                break;
            }
        }
  }
}

