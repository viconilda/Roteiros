package roteiro2;

import java.util.Scanner;

public class Programa09 {

    public static void main(String[] args) {
        
        Scanner entrada = new Scanner(System.in);
        
        int[] vetorNotas = new int[5];

       for (int cont = 0; cont < 5; cont++) {
            System.out.println("Informe uma nota: ");
            int nota = entrada.nextInt();
            
            if (nota >= 0 && nota <= 10) {
                vetorNotas[cont] = nota;
            } else {
                System.out.println("Nota invalida.");
                
                
            }
        }
        
        System.out.println("Notas validas: ");
        for (int nota = 0; nota < vetorNotas.length; nota++) {
            if (vetorNotas[nota] != 0) {
                System.out.println(vetorNotas[nota]);
            }
        }
    }
}
