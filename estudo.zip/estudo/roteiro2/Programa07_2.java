package roteiro2;

import java.util.Scanner;

public class Programa07_2 {
    
    public static void main(String[] args) {
        
        Scanner entrada = new Scanner(System.in);

        double n1,n2,media;
        
        
        System.out.println("Informe nota 1");
        n1 = entrada.nextDouble();
        System.out.println("Informe n2");
        n2 = entrada.nextDouble();
        media = (n1 + n2) /2.0;
        System.out.println("A media de  foi " + media);

        if (media >= 7 && media <= 10)
        {
            System.out.println("Aprovado");
        }

        if (media >= 0 && media < 6)
        {
            System.out.println("Reprovado");
        }

        int notaAcimaMedia = 0;
        if (n1 > media) {
            notaAcimaMedia++;
        }
        if (n2 > media) {
            notaAcimaMedia++;
        }
        System.out.println("Quantidade de notas acima da media: " + notaAcimaMedia);

    }

}

//Sim, é possível. Como podemos calcular as médias das notas, podemos ver qual a nota
//ficou acima da média e então podemos contar quantas notas ficaram acima da média.