package roteiro2;

import java.util.Scanner;

public class Programa06 {
    
    public static void main(String[] args) {
        
        Scanner entrada = new Scanner(System.in);
        
        int nota;
        boolean continuar = true;
        
        for (int cont = 0; continuar; cont++) {
            System.out.println("Informe uma nota ");
            nota = entrada.nextInt();
            
            if (nota <=-1 || nota >= 11) {
                continuar = false;
            }    
                else {
                
                if (nota >= 7) {
                    System.out.println("Aprovado");
                } else {
                    System.out.println("Reprovado");
                }
            }     
        }
    }  
} 
