package roteiro2;

import java.util.Scanner;

public class Programa07_1 {
    
    public static void main(String[] args) {
        
        Scanner entrada = new Scanner(System.in);

        double n1,n2,media;
        
        System.out.println("Informe nota 1");
        n1 = entrada.nextDouble();
        System.out.println("Informe n2");
        n2 = entrada.nextDouble();
        media = (n1 + n2) /2.0;
        System.out.println("A media de  foi " + media);

        if (media >= 7 && media <= 10)
        {
            System.out.println("Aprovado");
        }

        if (media >= 0 && media < 6)
        {
            System.out.println("Reprovado");
        }

    }
}
