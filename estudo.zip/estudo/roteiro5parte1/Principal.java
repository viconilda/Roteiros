package roteiro5parte1;

public class Principal {
    
    public static void main(String[] args) {
        
        Loja loja01 = new Loja("Lojão da Cidade", "Lojão Comércio LTDA", "11223344", 13000.0, 150.0, "Saulo");
        Loja loja02 = new Loja("Mercadão do Povo", "Mercado Comércio LTDA", "10101010", 15000.0, 200.0, "Rafael");
        
       
        System.out.println("Loja 01:");
        System.out.println("Nome Fantasia: " + loja01.getNomeFantasia());
        System.out.println("Razão Social: " + loja01.getRazaoSocial());
        System.out.println("CNPJ: " + loja01.getCnpj());
        System.out.println("Valor Faturamento: " + loja01.getValorFat());
        System.out.println("Área: " + loja01.getArea());
        System.out.println("Nome Proprietário: " + loja01.getNomeProprietario());
        
        System.out.println("Loja 02:");
        System.out.println("Nome Fantasia: " + loja02.getNomeFantasia());
        System.out.println("Razão Social: " + loja02.getRazaoSocial());
        System.out.println("CNPJ: " + loja02.getCnpj());
        System.out.println("Valor Faturamento: " + loja02.getValorFat());
        System.out.println("Área: " + loja02.getArea());
        System.out.println("Nome Proprietário: " + loja02.getNomeProprietario());
    }
}