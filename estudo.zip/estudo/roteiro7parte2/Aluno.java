package roteiro7parte2;

import java.util.ArrayList;
import java.util.Scanner;

public class Aluno {
    private int matricula;
    private String nome;
    private String curso;
    private int anoIngresso;

    public Aluno(int matricula, String nome, String curso, int anoIngresso) {
        this.matricula = matricula;
        this.nome = nome;
        this.curso = curso;
        this.anoIngresso = anoIngresso;
    }

    public int getMatricula() {
        return matricula;
    }

    public void setMatricula(int matricula) {
        this.matricula = matricula;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCurso() {
        return curso;
    }

    public void setCurso(String curso) {
        this.curso = curso;
    }

    public int getAnoIngresso() {
        return anoIngresso;
    }

    public void setAnoIngresso(int anoIngresso) {
        this.anoIngresso = anoIngresso;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<Aluno> listaAlunos = new ArrayList<>();

        for (int i = 0; i < 3; i++) {
            System.out.println("Informe os dados do aluno " + (i + 1) + ":");
            System.out.print("Matrícula: ");
            int matricula = scanner.nextInt();
            scanner.nextLine(); 
            System.out.print("Nome: ");
            String nome = scanner.nextLine();
            System.out.print("Curso: ");
            String curso = scanner.nextLine();
            System.out.print("Ano de Ingresso: ");
            int anoIngresso = scanner.nextInt();

            Aluno aluno = new Aluno(matricula, nome, curso, anoIngresso);
            listaAlunos.add(aluno);
        }

        System.out.println("Listando os Alunos:");
        System.out.println("********************************");
        for (Aluno aluno : listaAlunos) {
            System.out.println("Matrícula: " + aluno.getMatricula());
            System.out.println("Nome: " + aluno.getNome());
            System.out.println("Curso: " + aluno.getCurso());
            System.out.println("Ano de Ingresso: " + aluno.getAnoIngresso());
            System.out.println("********************************");
        }

        scanner.close();
    }
}
 
