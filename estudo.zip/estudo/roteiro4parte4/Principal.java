package roteiro4parte4;

import java.util.Scanner;

public class Principal {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Informe a matrícula:");
        int matricula = scanner.nextInt();
        scanner.nextLine(); 

        System.out.println("Informe o nome:");
        String nome = scanner.nextLine();

        System.out.println("Informe o curso:");
        String curso = scanner.nextLine();

        System.out.println("Informe o ano de ingresso:");
        int anoIngresso = scanner.nextInt();

        System.out.println("Informe a quantidade de disciplinas:");
        int qtdeDisciplinas = scanner.nextInt();

        System.out.println("Informe a situação (Matriculado ou Não Matriculado):");
        String situacao = scanner.next();

        Aluno aluno01 = new Aluno(matricula, nome, curso, anoIngresso, qtdeDisciplinas, situacao);
        
        System.out.println("\nDados do aluno:");
        System.out.println("Matricula : " + aluno01.getMatricula());
        System.out.println("Nome : " + aluno01.getNome());
        System.out.println("Curso : " + aluno01.getCurso());
        System.out.println("Ano Ingresso : " + aluno01.getAnoIngresso());
        System.out.println("Qtde Disciplinas : " + aluno01.getQtdeDisciplinas());
        System.out.println("Situação : " + aluno01.getSituacao());

        scanner.close();
    }
}