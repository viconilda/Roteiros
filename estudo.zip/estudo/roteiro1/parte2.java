package roteiro1;

public class parte2 {

    public static void main(String[] args) {

        double sb = 2500;
        int horaExtra = 10;
        double valorHoraExtra = sb/160;
        double horasExtras = (valorHoraExtra * horaExtra);
        double salarioTotal = sb + horasExtras;
        

        System.out.println("Salario total : " + salarioTotal);
        
    }
    
}
