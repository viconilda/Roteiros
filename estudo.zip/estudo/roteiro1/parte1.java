package roteiro1;
public class parte1{
    public static void main(String[] args) {
        System.out.println("Olá Mundo");
    }
} 


//"print Olá Mundo