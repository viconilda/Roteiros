package roteiros.roteiro10.parte2;

public class Principal {

    public static void main(String[] args) {
        new JanelaSemLayout();
        new JanelaFlowLayout();
        new JanelaGridLayout();
        new JanelaBorderLayout();
    }
}
