package roteiros.roteiro10.parte1;

public class Principal {
    public static void main(String[] args) {
        Janela01 janela01 = new Janela01();
        Janela02 janela02 = new Janela02();
    }
}
