package roteiros.roteiro10.parte3;

public class Principal {

    public static void main(String[] args) {
        new JanelaBorderLayoutV1();
        new JanelaBorderLayoutV2();
    }
}
