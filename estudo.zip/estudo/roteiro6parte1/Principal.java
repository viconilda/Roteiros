package roteiro6parte1;

class Ligacao {
    private String numOrigem;
    private String numDestino;
    private String localOrigem;  
    private String localDestino;
    private String horaInicio;
    private String horaFim;

    
    public Ligacao(String numOrigem, String numDestino, String localOrigem, String localDestino, String horaInicio) {
        this.numOrigem = numOrigem;
        this.numDestino = numDestino;
        this.localOrigem = localOrigem;
        this.localDestino = localDestino;
        this.horaInicio = horaInicio;
        this.horaFim = "";
    }

   
    public String getNumOrigem() {
        return numOrigem;
    }

    public void setNumOrigem(String numOrigem) {
        this.numOrigem = numOrigem;
    }

    public String getNumDestino() {
        return numDestino;
    }

    public void setNumDestino(String numDestino) {
        this.numDestino = numDestino;
    }

    public String getLocalOrigem() {
        return localOrigem;
    }

    public void setLocalOrigem(String localOrigem) {
        this.localOrigem = localOrigem;
    }

    public String getLocalDestino() {
        return localDestino;
    }

    public void setLocalDestino(String localDestino) {
        this.localDestino = localDestino;
    }

    public String getHoraInicio() {
        return horaInicio;
    }

    public void setHoraInicio(String horaInicio) {
        this.horaInicio = horaInicio;
    }

    public String getHoraFim() {
        return horaFim;
    }

    public void setHoraFim(String horaFim) {
        this.horaFim = horaFim;
    }

    
    public void encerrarLigacao(String horaFim) {
        this.horaFim = horaFim;
    }

    public String calcularDuracao() {
        if (horaInicio.isEmpty() || horaFim.isEmpty()) {
            return "Não é possível calcular a duração. Horários de início ou término não estão preenchidos.";
        }

        return "Duração da ligação: Desconhecida";
    }
}


public class Principal {
    public static void main(String[] args) {
        
        Ligacao lig01 = new Ligacao("121212", "565656", "A", "B", "10:15:02");

       
        System.out.println("Número de Origem: " + lig01.getNumOrigem());
        System.out.println("Número de Destino: " + lig01.getNumDestino());
        System.out.println("Local de Origem: " + lig01.getLocalOrigem());
        System.out.println("Local de Destino: " + lig01.getLocalDestino());
        System.out.println("Hora de Início: " + lig01.getHoraInicio());
        System.out.println("Hora de Término: " + lig01.getHoraFim());

    
        lig01.encerrarLigacao("10:20:35");

        
        System.out.println(lig01.calcularDuracao());
    }
}