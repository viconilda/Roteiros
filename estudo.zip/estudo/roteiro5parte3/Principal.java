package roteiro5parte3;

public class Principal {
    
    public static void main(String[] args) {
        
      Loja loja01 = new Loja("Lojão da Cidade", "Lojão Comércio LTDA", "11223344");
      Loja loja02 = new Loja("Mercadão do Povo", "", "10101010");
      Loja loja03 = new Loja("Lojão da Cidade", "Lojão Comércio LTDA", "11223344");

      loja01.setValorFat(10000);
      loja02.setValorFat(20000);
      loja03.setValorFat(10000);


      System.out.println("  Comparação com método estático ");
      Loja.compararFatStatic(loja01, loja02);
        
      System.out.println("  Comparação com método não estático");
      loja01.compararFatNaoStatic(loja02);
        
      System.out.println(" Comparação com método não estático ");
      loja02.compararFatNaoStatic(loja01);
  }
}